# IMDB-Movie-Data-Analysis
I’m excited to share my project, "IMDB Movie Data Analysis with Python." This project deepened my skills in data analysis and cleaning using pandas, numpy, matplotlib, and seaborn. It involved analyzing student performance data to uncover insights, enhancing my ability to derive actionable conclusions from data.
